SaveBlobs created by @if0xxx

README

This is just a automatation for tsschecker by @tihmstar

Supports MacOS and Linux


How to Setup everything:
1. cd into SaveBlobs
2. drag and drop the Setup into the terminal
3. Setup everything

How to use:
1. cd into SaveBlobs
2. Drag and Drop the SaveBlobs file
3. ???
4. Profit 

if you want to use code out of this project please be kind and ask ;) 